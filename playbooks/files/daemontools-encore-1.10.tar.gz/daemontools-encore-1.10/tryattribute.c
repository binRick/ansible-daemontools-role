void test(void) __attribute__((noreturn));
