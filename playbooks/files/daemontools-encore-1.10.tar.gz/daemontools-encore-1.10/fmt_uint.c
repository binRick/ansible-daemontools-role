/* Public domain. */

#include "fmt.h"

unsigned int fmt_uint(char *s,unsigned int u)
{
  return fmt_ulong(s,u);
}
