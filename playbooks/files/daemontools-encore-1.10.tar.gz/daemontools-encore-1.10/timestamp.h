#ifndef TIMESTAMP_H
#define TIMESTAMP_H

#define TIMESTAMP 25

extern int fmt_tai64nstamp(char *);
extern int fmt_accustamp(char *);

#endif
